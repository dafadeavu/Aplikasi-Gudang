package com.gudang.project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
